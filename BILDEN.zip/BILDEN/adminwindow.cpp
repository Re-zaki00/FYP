#include "adminwindow.h"
#include "ui_adminwindow.h"

AdminWindow::AdminWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AdminWindow)
{
    ui->setupUi(this);

    // Connect the clicked signal of the View_Reports button to the slot function
    connect(ui->Viewreports, &QPushButton::clicked, this, &AdminWindow::openView_Report);
    connect(ui->ARegister, &QPushButton::clicked, this, &AdminWindow::openRegister);
}

AdminWindow::~AdminWindow()
{
    delete ui;
}

void AdminWindow::openView_Report()
{
    // Create an instance of the ViewReports widget
    View_Report* view_reports = new View_Report(this);

    // Show the ViewReports widget
    view_reports->show();
}

void AdminWindow::openRegister()
{
    // Create an instance of the Register widget
    Register* aregister = new Register(this);

    // Show the Register widget
    aregister->show();
}

#ifndef VIEWREPORTS_H
#define VIEWREPORTS_H

#include <QWidget>

namespace Ui {
class ViewReports;
}

class ViewReports : public QWidget
{
    Q_OBJECT

public:
    explicit ViewReports(QWidget *parent = nullptr);
    ~ViewReports();

private:
    Ui::ViewReports *ui;
};

#endif // VIEWREPORTS_H

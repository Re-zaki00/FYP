#include "viewreports.h"
#include "ui_viewreports.h"

View_Reports::View_Reports(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ViewReports)
{
    ui->setupUi(this);
}

View_Reports::~View_Reports()
{
    delete ui;
}

# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Register.ui'
##
## Created by: Qt User Interface Compiler version 6.4.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QGroupBox, QLabel, QLineEdit,
    QPushButton, QSizePolicy, QWidget)

class Ui_Register(object):
    def setupUi(self, Register):
        if not Register.objectName():
            Register.setObjectName(u"Register")
        Register.resize(1071, 653)
        Register.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.groupBox = QGroupBox(Register)
        self.groupBox.setObjectName(u"groupBox")
        self.groupBox.setGeometry(QRect(100, 60, 861, 531))
        font = QFont()
        font.setPointSize(11)
        font.setBold(True)
        font.setItalic(True)
        self.groupBox.setFont(font)
        self.groupBox.setLayoutDirection(Qt.LeftToRight)
        self.groupBox.setStyleSheet(u"background-color: rgb(91, 15, 255);\n"
"gridline-color: rgb(0, 0, 0);")
        self.groupBox.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.label = QLabel(self.groupBox)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(30, 120, 141, 51))
        self.label.setFont(font)
        self.label.setLayoutDirection(Qt.LeftToRight)
        self.label.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.label.setAlignment(Qt.AlignJustify|Qt.AlignVCenter)
        self.RName = QLineEdit(self.groupBox)
        self.RName.setObjectName(u"RName")
        self.RName.setGeometry(QRect(190, 120, 631, 51))
        self.RName.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.RName.setAlignment(Qt.AlignCenter)
        self.RPass = QLineEdit(self.groupBox)
        self.RPass.setObjectName(u"RPass")
        self.RPass.setGeometry(QRect(190, 300, 631, 51))
        self.RPass.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);\n"
"color: rgb(255, 255, 255);")
        self.RPass.setAlignment(Qt.AlignCenter)
        self.label_2 = QLabel(self.groupBox)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(30, 210, 141, 51))
        self.label_2.setFont(font)
        self.label_2.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.label_2.setAlignment(Qt.AlignJustify|Qt.AlignVCenter)
        self.label_3 = QLabel(self.groupBox)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(30, 300, 141, 51))
        self.label_3.setFont(font)
        self.label_3.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.label_3.setAlignment(Qt.AlignJustify|Qt.AlignVCenter)
        self.REmail = QLineEdit(self.groupBox)
        self.REmail.setObjectName(u"REmail")
        self.REmail.setGeometry(QRect(190, 210, 631, 51))
        self.REmail.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.REmail.setAlignment(Qt.AlignCenter)
        self.Back = QPushButton(self.groupBox)
        self.Back.setObjectName(u"Back")
        self.Back.setGeometry(QRect(450, 440, 101, 51))
        self.Back.setFont(font)
        self.Back.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.RConfirm = QPushButton(self.groupBox)
        self.RConfirm.setObjectName(u"RConfirm")
        self.RConfirm.setGeometry(QRect(270, 440, 101, 51))
        self.RConfirm.setFont(font)
        self.RConfirm.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.label_4 = QLabel(self.groupBox)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(30, 40, 791, 61))
        font1 = QFont()
        font1.setFamilies([u"Segoe UI"])
        font1.setPointSize(12)
        font1.setBold(True)
        font1.setItalic(True)
        font1.setUnderline(True)
        self.label_4.setFont(font1)
        self.label_4.setLayoutDirection(Qt.LeftToRight)
        self.label_4.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"text-decoration: underline;\n"
"font: 700 italic 12pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.label_4.setAlignment(Qt.AlignCenter)

        self.retranslateUi(Register)

        QMetaObject.connectSlotsByName(Register)
    # setupUi

    def retranslateUi(self, Register):
        Register.setWindowTitle(QCoreApplication.translate("Register", u"Widget", None))
        self.groupBox.setTitle(QCoreApplication.translate("Register", u"Bilden", None))
        self.label.setText(QCoreApplication.translate("Register", u"        Name : ", None))
        self.label_2.setText(QCoreApplication.translate("Register", u"       E-Mail :", None))
        self.label_3.setText(QCoreApplication.translate("Register", u"      Password :", None))
        self.Back.setText(QCoreApplication.translate("Register", u"Back", None))
        self.RConfirm.setText(QCoreApplication.translate("Register", u"Confirm", None))
        self.label_4.setText(QCoreApplication.translate("Register", u"Register Members :", None))
    # retranslateUi


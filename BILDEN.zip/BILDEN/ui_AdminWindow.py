# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'adminwindow.ui'
##
## Created by: Qt User Interface Compiler version 6.4.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QGroupBox, QPushButton, QSizePolicy,
    QWidget)

class Ui_AdminWindow(object):
    def setupUi(self, AdminWindow):
        if not AdminWindow.objectName():
            AdminWindow.setObjectName(u"AdminWindow")
        AdminWindow.resize(1071, 653)
        AdminWindow.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.groupBox = QGroupBox(AdminWindow)
        self.groupBox.setObjectName(u"groupBox")
        self.groupBox.setGeometry(QRect(10, 10, 1051, 631))
        font = QFont()
        font.setPointSize(11)
        font.setBold(True)
        font.setItalic(True)
        self.groupBox.setFont(font)
        self.groupBox.setStyleSheet(u"background-color: rgb(91, 15, 255);")
        self.View_reports = QPushButton(self.groupBox)
        self.View_reports.setObjectName(u"View_reports")
        self.View_reports.setGeometry(QRect(230, 140, 581, 71))
        font1 = QFont()
        font1.setPointSize(10)
        font1.setBold(True)
        font1.setItalic(True)
        self.View_reports.setFont(font1)
        self.View_reports.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
                                         "color: rgb(255, 255, 255);")
        self.aregister = QPushButton(self.groupBox)
        self.aregister.setObjectName(u"aregister")
        self.aregister.setGeometry(QRect(230, 290, 581, 71))
        self.aregister.setFont(font1)
        self.aregister.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
                                     "color: rgb(255, 255, 255);")


        self.retranslateUi(AdminWindow)

        QMetaObject.connectSlotsByName(AdminWindow)
    # setupUi

    def retranslateUi(self, AdminWindow):
        AdminWindow.setWindowTitle(QCoreApplication.translate("AdminWindow", u"Form", None))
        self.groupBox.setTitle(QCoreApplication.translate("AdminWindow", u"Bilden", None))
        self.View_reports.setText(QCoreApplication.translate("AdminWindow", u"View_reports", None))
        self.aregister.setText(QCoreApplication.translate("AdminWindow", u"Register", None))
    # retranslateUi


# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'viewreports.ui'
##
## Created by: Qt User Interface Compiler version 6.4.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QComboBox, QDialogButtonBox,
    QPlainTextEdit, QScrollArea, QScrollBar, QSizePolicy,
    QTabWidget, QWidget)

class Ui_Report(object):
    def setupUi(self, Report):
        if not Report.objectName():
            Report.setObjectName(u"Report")
        Report.resize(1071, 653)
        Report.setStyleSheet(u"background-color: rgb(10, 6, 65);")
        self.scrollArea = QScrollArea(Report)
        self.scrollArea.setObjectName(u"scrollArea")
        self.scrollArea.setGeometry(QRect(0, 80, 1071, 571))
        self.scrollArea.setWidgetResizable(True)
        self.scrollAreaWidgetContents_4 = QWidget()
        self.scrollAreaWidgetContents_4.setObjectName(u"scrollAreaWidgetContents_4")
        self.scrollAreaWidgetContents_4.setGeometry(QRect(0, 0, 1069, 569))
        self.plainTextEdit_4 = QPlainTextEdit(self.scrollAreaWidgetContents_4)
        self.plainTextEdit_4.setObjectName(u"plainTextEdit_4")
        self.plainTextEdit_4.setGeometry(QRect(0, 0, 1071, 571))
        self.plainTextEdit_4.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"selection-color: rgb(255, 255, 0);\n"
"selection-background-color: rgb(85, 0, 255);")
        self.verticalScrollBar_4 = QScrollBar(self.scrollAreaWidgetContents_4)
        self.verticalScrollBar_4.setObjectName(u"verticalScrollBar_4")
        self.verticalScrollBar_4.setGeometry(QRect(1050, 0, 21, 551))
        self.verticalScrollBar_4.setStyleSheet(u"background-color: qlineargradient(spread:pad, x1:0.50661, y1:0.017, x2:0.511695, y2:0.966, stop:1 rgba(101, 101, 102, 255));")
        self.verticalScrollBar_4.setOrientation(Qt.Vertical)
        self.horizontalScrollBar_4 = QScrollBar(self.scrollAreaWidgetContents_4)
        self.horizontalScrollBar_4.setObjectName(u"horizontalScrollBar_4")
        self.horizontalScrollBar_4.setGeometry(QRect(-1, 549, 1071, 21))
        self.horizontalScrollBar_4.setStyleSheet(u"background-color: qlineargradient(spread:pad, x1:0.50661, y1:0.017, x2:0.511695, y2:0.966, stop:1 rgba(101, 101, 102, 255));\n"
"background-color: rgb(170, 85, 127);\n"
"color: rgb(0, 0, 0);")
        self.horizontalScrollBar_4.setOrientation(Qt.Horizontal)
        self.scrollArea.setWidget(self.scrollAreaWidgetContents_4)
        self.tabWidget = QTabWidget(Report)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setGeometry(QRect(0, 0, 1071, 80))
        self.tabWidget.setStyleSheet(u"background-color: rgb(0, 170, 255);\n"
"color: rgb(0, 0, 0);")
        self.tab_7 = QWidget()
        self.tab_7.setObjectName(u"tab_7")
        self.tabWidget.addTab(self.tab_7, "")
        self.tab_8 = QWidget()
        self.tab_8.setObjectName(u"tab_8")
        self.buttonBox_4 = QDialogButtonBox(self.tab_8)
        self.buttonBox_4.setObjectName(u"buttonBox_4")
        self.buttonBox_4.setGeometry(QRect(880, 0, 167, 51))
        self.buttonBox_4.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)
        self.comboBox_13 = QComboBox(self.tab_8)
        self.comboBox_13.addItem("")
        self.comboBox_13.setObjectName(u"comboBox_13")
        self.comboBox_13.setGeometry(QRect(0, 10, 61, 31))
        self.comboBox_15 = QComboBox(self.tab_8)
        self.comboBox_15.addItem("")
        self.comboBox_15.setObjectName(u"comboBox_15")
        self.comboBox_15.setGeometry(QRect(60, 10, 71, 31))
        self.tabWidget.addTab(self.tab_8, "")

        self.retranslateUi(Report)

        self.tabWidget.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(Report)
    # setupUi

    def retranslateUi(self, Report):
        Report.setWindowTitle(QCoreApplication.translate("Report", u"Form", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_7), QCoreApplication.translate("Report", u"Tab 1", None))
        self.comboBox_13.setItemText(0, QCoreApplication.translate("Report", u"File", None))

        self.comboBox_15.setItemText(0, QCoreApplication.translate("Report", u"View", None))

        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_8), QCoreApplication.translate("Report", u"Tab 2", None))
    # retranslateUi

